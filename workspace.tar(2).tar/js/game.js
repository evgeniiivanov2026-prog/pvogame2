// PVOGame.ru - Game Engine
// Vanilla JavaScript

// ==================== CONFIG ====================
const CONFIG = {
  CANVAS_W: 1280, CANVAS_H: 720,
  STATION: { x: 640, y: 360, radius: 28, maxIntegrity: 100 },
  RINGS: [
    { key: 'detection', radius: 340, color: 'rgba(0,212,255,0.08)' },
    { key: 'far', radius: 260, color: 'rgba(0,255,136,0.06)' },
    { key: 'medium', radius: 180, color: 'rgba(255,204,0,0.06)' },
    { key: 'close', radius: 100, color: 'rgba(255,51,85,0.08)' },
  ],
  START: { credits: 500, energy: 10, maxEnergy: 10, focus: 65, stress: 10, composure: 100 },
  ENEMIES: {
    scout: { name: 'Scout', hp: 20, speed: 2.5, size: 10, dmg: 8, reward: 15, score: 10, color: '#00ff88', shape: 'triangle', threat: 2 },
    swarm: { name: 'Swarm Unit', hp: 8, speed: 1.8, size: 6, dmg: 3, reward: 5, score: 5, color: '#ffcc00', shape: 'diamond', threat: 1, count: 5 },
    armored: { name: 'Armored Carrier', hp: 120, speed: 0.8, size: 22, dmg: 20, reward: 60, score: 50, color: '#aa55ff', shape: 'hexagon', threat: 4, spawns: 3 },
    decoy: { name: 'Decoy', hp: 15, speed: 2.0, size: 12, dmg: 5, reward: 20, score: 15, color: '#ff8800', shape: 'square', threat: 4 },
    wisp: { name: 'Signal Wisp', hp: 30, speed: 1.5, size: 14, dmg: 0, reward: 25, score: 20, color: '#00d4ff', shape: 'ring', threat: 3, disruptRadius: 80 },
  },
  MODULES: {
    sentinel: { name: 'Sentinel Sensor', desc: 'Обнаружение', cost: 80, energy: 1, range: 200, cooldown: 0, damage: 0, color: '#00d4ff', kind: 'sensor', upgrades: [{ range: 240, cost: 60 }, { range: 280, cost: 100 }] },
    veil: { name: 'Signal Veil', desc: 'Замедление', cost: 120, energy: 2, range: 150, cooldown: 5000, damage: 0, color: '#aa55ff', kind: 'utility', slow: 0.5, slowDur: 2000, upgrades: [{ slow: 0.6, cost: 80 }, { slow: 0.7, cooldown: 4000, cost: 120 }] },
    arc: { name: 'Arc Interceptor', desc: 'Одиночная цель', cost: 150, energy: 2, range: 200, cooldown: 1200, damage: 25, color: '#00ff88', kind: 'weapon', upgrades: [{ damage: 35, cost: 100 }, { damage: 50, cooldown: 1000, cost: 150 }] },
    pulse: { name: 'Pulse Array', desc: 'Зона', cost: 200, energy: 3, range: 160, cooldown: 3000, damage: 15, color: '#ffcc00', kind: 'weapon', aoe: 60, maxT: 4, upgrades: [{ damage: 20, maxT: 5, cost: 120 }, { damage: 30, aoe: 80, cost: 180 }] },
    guardian: { name: 'Guardian Node', desc: 'Ближний рубеж', cost: 100, energy: 1, range: 100, cooldown: 600, damage: 18, color: '#ff3355', kind: 'weapon', upgrades: [{ damage: 25, cooldown: 500, cost: 80 }, { damage: 35, cooldown: 400, cost: 120 }] },
  },
  PRIORITIES: [
    { id: 'closest', name: 'Ближайшая' },
    { id: 'fastest', name: 'Быстрая' },
    { id: 'strongest', name: 'Прочная' },
    { id: 'highestThreat', name: 'Угроза' },
    { id: 'weakest', name: 'Слабая' },
    { id: 'longest', name: 'Долго в зоне' },
  ],
  WAVES: [
    { enemies: [{ type: 'scout', count: 3 }], delay: 2000 },
    { enemies: [{ type: 'scout', count: 5 }], delay: 1800 },
    { enemies: [{ type: 'scout', count: 6 }], delay: 1500 },
    { enemies: [{ type: 'swarm', count: 2, swarm: 5 }], delay: 2000 },
    { enemies: [{ type: 'scout', count: 3 }, { type: 'decoy', count: 2 }], delay: 1500 },
    { enemies: [{ type: 'swarm', count: 3, swarm: 4 }, { type: 'decoy', count: 1 }], delay: 1200 },
    { enemies: [{ type: 'armored', count: 1 }, { type: 'scout', count: 3 }], delay: 2000 },
    { enemies: [{ type: 'wisp', count: 2 }, { type: 'swarm', count: 2, swarm: 4 }], delay: 1500 },
    { enemies: [{ type: 'armored', count: 2 }, { type: 'decoy', count: 2 }], delay: 1800 },
    { enemies: [{ type: 'scout', count: 4 }, { type: 'armored', count: 1 }, { type: 'wisp', count: 1 }], delay: 1200 },
    { enemies: [{ type: 'swarm', count: 3, swarm: 5 }, { type: 'armored', count: 2 }], delay: 1000 },
    { enemies: [{ type: 'scout', count: 3 }, { type: 'armored', count: 2 }, { type: 'wisp', count: 2 }, { type: 'decoy', count: 2 }], delay: 800 },
  ],
  PERKS: [
    { id: 'sensor_range', name: 'Сенсоры', desc: '+15% дальность' },
    { id: 'arc_cooldown', name: 'Разряд', desc: '-12% кулдаун Arc' },
    { id: 'veil_slow', name: 'Поле', desc: '+15% замедление' },
    { id: 'max_energy', name: 'Батарея', desc: '+2 энергии' },
    { id: 'armored_reward', name: 'Охотник', desc: '+25% Carrier' },
    { id: 'pulse_targets', name: 'Импульс', desc: '+2 цели Pulse' },
    { id: 'station_armor', name: 'Броня', desc: '+15 прочности' },
    { id: 'credit_bonus', name: 'Ресурсы', desc: '+10% кредитов' },
    { id: 'start_credits', name: 'Капитал', desc: '+100 кредитов' },
    { id: 'guardian_burst', name: 'Импульс', desc: 'Guardian x2' },
  ],
  RECOVERY: {
    'analysis-pause': { focus: 25, cd: 32000, dur: 4500, stress: -5, composure: 6, name: 'Анализ' },
    'channel-priority': { focus: 18, cd: 25000, dur: 9000, stress: -8, composure: 5, name: 'Канал' },
    'network-breath': { focus: 15, cd: 20000, dur: 7000, stress: -10, composure: 12, name: 'Дыхание' },
    'clarity-protocol': { focus: 45, cd: 75000, dur: 12000, stress: -15, composure: 20, name: 'Ясность' },
  },
};

// ==================== UTILS ====================
const dist = (x1, y1, x2, y2) => Math.sqrt((x2 - x1) ** 2 + (y2 - y1) ** 2);
const ang = (x1, y1, x2, y2) => Math.atan2(y2 - y1, x2 - x1);
const rnd = (a, b) => Math.random() * (b - a) + a;
const rndI = (a, b) => Math.floor(Math.random() * (b - a + 1)) + a;
const shuffle = (a) => { const r = [...a]; for (let i = r.length - 1; i > 0; i--) { const j = Math.floor(Math.random() * (i + 1)); [r[i], r[j]] = [r[j], r[i]]; } return r; };
const edgePos = () => { const s = rndI(0, 3), m = 40; switch (s) { case 0: return { x: rnd(m, CONFIG.CANVAS_W - m), y: -m }; case 1: return { x: CONFIG.CANVAS_W + m, y: rnd(m, CONFIG.CANVAS_H - m) }; case 2: return { x: rnd(m, CONFIG.CANVAS_W - m), y: CONFIG.CANVAS_H + m }; default: return { x: -m, y: rnd(m, CONFIG.CANVAS_H - m) }; } };
let _id = 0; const gid = () => `id${++_id}`;
const clamp = (v, a, b) => Math.max(a, Math.min(b, v));

// ==================== GAME STATE ====================
let gameState = null;
let audioMgr = null;
let canvas = null;
let ctx = null;
let lastTime = 0;
let animId = 0;

function initState() {
  const saved = loadSave();
  return {
    phase: 'menu', credits: CONFIG.START.credits, energy: CONFIG.START.energy, maxEnergy: CONFIG.START.maxEnergy,
    integrity: CONFIG.STATION.maxIntegrity, maxIntegrity: CONFIG.STATION.maxIntegrity,
    score: 0, wave: 0, killed: 0, enemies: [], modules: [], effects: [],
    events: [], selModId: null, hiEnemyId: null, placeType: null,
    mouseX: 0, mouseY: 0, speed: 1,
    spawnQ: [], spawnT: 0, waveActive: false, endless: false,
    perks: { sensorRange: 1, arcCooldown: 1, veilSlow: 0, armoredReward: 1, guardianBurst: false, pulseTargets: 0, creditBonus: 1 },
    stress: CONFIG.START.stress, composure: CONFIG.START.composure, focus: CONFIG.START.focus, panic: 'calm',
    recovery: { mode: null, timer: 0, cooldowns: {} },
    soundOn: saved.sound ?? true, highContrast: saved.highContrast ?? false,
    reduceMotion: saved.reduceMotion ?? false, reduceVisual: saved.reduceVisual ?? false,
    bestScore: saved.bestScore ?? 0, bestWave: saved.bestWave ?? 0,
    focusVisual: 'steady', difficulty: 'standard',
    terrainSeed: saved.terrainSeed ?? 42, terrain: { regions: [], obstacles: [] },
    adminOpen: false, adminTab: 'overview',
    musicPlaying: false, musicVolume: 0.5, musicFiles: [], currentMusicIndex: 0,
  };
}

// ==================== STORAGE ====================
function loadSave() { try { const r = localStorage.getItem('pvogame-settings'); if (r) return JSON.parse(r); } catch {} return { bestScore: 0, bestWave: 0, sound: true, highContrast: false, reduceMotion: false, reduceVisual: false, terrainSeed: 42 }; }
function saveSave(d) { try { localStorage.setItem('pvogame-settings', JSON.stringify(d)); } catch {} }
function saveBest(score, wave) { const d = loadSave(); if (score > d.bestScore) d.bestScore = score; if (wave > d.bestWave) d.bestWave = wave; saveSave(d); }
function saveSettings(s) { const d = loadSave(); Object.assign(d, s); saveSave(d); }
function clearSave() { try { localStorage.removeItem('pvogame-settings'); } catch {} }

// ==================== AUDIO ====================
class AudioMgr {
  constructor() { this.ctx = null; this.master = null; this.muted = false; this.vol = 0.5; this.musicElement = null; this.musicGain = null; }
  init() { try { this.ctx = new (window.AudioContext || window.webkitAudioContext)(); this.master = this.ctx.createGain(); this.master.gain.value = this.vol; this.musicGain = this.ctx.createGain(); this.musicGain.gain.value = 0.5; this.musicGain.connect(this.master); this.master.connect(this.ctx.destination); } catch {} }
  unlock() { if (this.ctx?.state === 'suspended') this.ctx.resume(); }
  setVol(v) { this.vol = v; if (this.master) this.master.gain.value = this.muted ? 0 : v; }
  setMuted(m) { this.muted = m; if (this.master) this.master.gain.value = m ? 0 : this.vol; }
  setMusicVol(v) { if (this.musicGain) this.musicGain.gain.value = v; }
  tone(freq, dur, type = 'sine', vol = 0.1) {
    if (!this.ctx || this.muted) return;
    try { const o = this.ctx.createOscillator(), g = this.ctx.createGain(); o.type = type; o.frequency.value = freq; g.gain.setValueAtTime(vol, this.ctx.currentTime); g.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + dur); o.connect(g); g.connect(this.master); o.start(); o.stop(this.ctx.currentTime + dur); } catch {}
  }
  click() { this.tone(600, 0.05, 'sine', 0.05); }
  place() { this.tone(400, 0.1, 'triangle', 0.08); }
  upgrade() { this.tone(500, 0.1, 'sine', 0.08); setTimeout(() => this.tone(700, 0.15, 'sine', 0.08), 80); }
  hit() { this.tone(150, 0.2, 'square', 0.08); }
  waveStart() { this.tone(400, 0.1, 'sine', 0.06); setTimeout(() => this.tone(600, 0.15, 'sine', 0.06), 100); }
  waveEnd() { this.tone(500, 0.15, 'sine', 0.06); setTimeout(() => this.tone(700, 0.2, 'sine', 0.06), 120); }
  gameOver() { this.tone(400, 0.3, 'sawtooth', 0.1); setTimeout(() => this.tone(200, 0.5, 'sawtooth', 0.1), 200); }
  recovery() { this.tone(600, 0.2, 'sine', 0.05); }
  loadMusic(url) { if (this.musicElement) { this.musicElement.pause(); } this.musicElement = new Audio(url); if (this.ctx && this.musicGain) { try { const src = this.ctx.createMediaElementSource(this.musicElement); src.connect(this.musicGain); } catch {} } }
  playMusic() { this.musicElement?.play(); }
  pauseMusic() { this.musicElement?.pause(); }
  stopMusic() { if (this.musicElement) { this.musicElement.pause(); this.musicElement.currentTime = 0; } }
}

// ==================== TERRAIN ====================
function generateTerrain(seed) {
  const regions = [], obstacles = [];
  const cx = CONFIG.STATION.x, cy = CONFIG.STATION.y;
  const safeRadius = CONFIG.RINGS[3].radius + 30;
  const archetypes = ['auroraRidges', 'quietBasins', 'fracturedPlateau', 'crystalVeins', 'signalTide'];
  const obsTypes = ['prismCluster', 'echoPillar', 'fracturedShard', 'lumenArch', 'driftStone'];
  
  // Regions
  for (let i = 0; i < 5; i++) {
    const angle = rnd(0, Math.PI * 2);
    const distance = 100 + rnd(0, 250);
    const x = cx + Math.cos(angle) * distance;
    const y = cy + Math.sin(angle) * distance;
    if (dist(x, y, cx, cy) < safeRadius) continue;
    const arch = archetypes[i % archetypes.length];
    regions.push({ name: arch, x, y, radius: 40 + rnd(0, 60), color: 'rgba(0,212,255,0.1)' });
  }
  
  // Obstacles
  for (let i = 0; i < 15; i++) {
    const x = rnd(50, CONFIG.CANVAS_W - 50);
    const y = rnd(50, CONFIG.CANVAS_H - 50);
    if (dist(x, y, cx, cy) < safeRadius) continue;
    const type = obsTypes[i % obsTypes.length];
    obstacles.push({ id: gid(), type, x, y, size: 8 + rnd(0, 12), rotation: rnd(0, Math.PI * 2), color: '#00d4ff' });
  }
  
  return { regions, obstacles };
}

// ==================== ENTITIES ====================
class Enemy {
  constructor(type, x, y, hpS = 1, spS = 1) {
    const t = CONFIG.ENEMIES[type];
    Object.assign(this, {
      id: gid(), type, x, y, hp: t.hp * hpS, maxHp: t.hp * hpS,
      speed: t.speed * spS, baseSpeed: t.speed * spS,
      size: t.size, dmg: t.dmg, reward: t.reward, score: t.score,
      color: t.color, shape: t.shape, alive: true, reached: false,
      slowT: 0, slowA: 0, trail: [], timeIn: 0,
      angle: ang(x, y, CONFIG.STATION.x, CONFIG.STATION.y),
      evT: 0, evD: 1, flickV: true, flickT: 0, disA: false, disT: 0,
      swarmOff: { x: rnd(-20, 20), y: rnd(-20, 20) }
    });
  }
  
  update(dt) {
    if (!this.alive) return;
    const sx = CONFIG.STATION.x, sy = CONFIG.STATION.y;
    if (this.slowT > 0) { this.slowT -= dt; this.speed = this.baseSpeed * (1 - this.slowA); }
    else { this.speed = this.baseSpeed; this.slowA = 0; }
    this.timeIn += dt;
    
    const dx = sx - this.x, dy = sy - this.y, d = Math.sqrt(dx * dx + dy * dy);
    
    if (this.type === 'scout') {
      this.evT -= dt; if (this.evT <= 0) { this.evD = Math.random() > 0.5 ? 1 : -1; this.evT = rnd(500, 2000); }
      const a = ang(this.x, this.y, sx, sy), pa = a + (Math.PI / 2) * this.evD;
      this.x += (Math.cos(a) * 0.7 + Math.cos(pa) * 0.3) * this.speed * dt * 0.06;
      this.y += (Math.sin(a) * 0.7 + Math.sin(pa) * 0.3) * this.speed * dt * 0.06;
      this.angle = a;
    } else if (this.type === 'swarm') {
      const tx = sx + this.swarmOff.x, ty = sy + this.swarmOff.y;
      const tdx = tx - this.x, tdy = ty - this.y, td = Math.sqrt(tdx * tdx + tdy * tdy);
      if (td > 0) { this.x += (tdx / td) * this.speed * dt * 0.06; this.y += (tdy / td) * this.speed * dt * 0.06; }
      this.angle = ang(this.x, this.y, tx, ty);
    } else if (this.type === 'decoy') {
      this.flickT -= dt; if (this.flickT <= 0) { this.flickV = !this.flickV; this.flickT = rnd(100, 400); }
      if (d > 0) { this.x += (dx / d) * this.speed * dt * 0.06; this.y += (dy / d) * this.speed * dt * 0.06; }
      this.angle = ang(this.x, this.y, sx, sy);
    } else if (this.type === 'wisp') {
      if (d > 0) { this.x += (dx / d) * this.speed * dt * 0.06; this.y += (dy / d) * this.speed * dt * 0.06; }
      this.angle = ang(this.x, this.y, sx, sy);
      if (dist(this.x, this.y, sx, sy) < 160 && !this.disA) { this.disA = true; this.disT = 3000; }
      if (this.disA) { this.disT -= dt; if (this.disT <= 0) this.disA = false; }
    } else {
      if (d > 0) { this.x += (dx / d) * this.speed * dt * 0.06; this.y += (dy / d) * this.speed * dt * 0.06; }
      this.angle = ang(this.x, this.y, sx, sy);
    }
    
    this.trail.push({ x: this.x, y: this.y }); if (this.trail.length > 8) this.trail.shift();
    if (dist(this.x, this.y, sx, sy) <= CONFIG.STATION.radius + this.size) { this.reached = true; this.alive = false; }
  }
  
  takeDamage(dmg) {
    this.hp -= dmg;
    if (this.hp <= 0) { this.hp = 0; this.alive = false; return true; }
    return false;
  }
}

function getThreat(e) {
  const d = dist(e.x, e.y, CONFIG.STATION.x, CONFIG.STATION.y);
  const df = 1 - Math.min(d / CONFIG.RINGS[0].radius, 1);
  let b = CONFIG.ENEMIES[e.type].threat;
  if (e.type === 'decoy') b += Math.random();
  const sf = Math.min(CONFIG.ENEMIES[e.type].speed / 3, 1);
  return clamp(Math.round(b * 0.4 + df * 3 * 0.3 + sf * 2 * 0.2 + (e.hp / e.maxHp) * 2 * 0.1), 1, 5);
}

// ==================== MODULES ====================
class Module {
  constructor(type, x, y) {
    const t = CONFIG.MODULES[type];
    Object.assign(this, {
      id: gid(), type, x, y, name: t.name, level: 1, maxLevel: 3,
      range: t.range, cooldown: t.cooldown, cdT: 0, damage: t.damage,
      color: t.color, kind: t.kind, energy: t.energy, invested: t.cost,
      active: true, lowPow: false, disrupted: false, disT: 0,
      priority: 'closest', target: null, slow: t.slow || 0, slowDur: t.slowDur || 0,
      aoe: t.aoe || 0, maxT: t.maxT || 1, phase: Math.random() * Math.PI * 2,
      fireA: 0, fX: 0, fY: 0
    });
  }
  
  update(dt, enemies, state) {
    if (!this.active || this.disrupted) return;
    if (this.cdT > 0) { this.cdT -= dt; return; }
    
    const cands = enemies.filter(e => e.alive && dist(this.x, this.y, e.x, e.y) <= this.range);
    if (!cands.length) { this.target = null; return; }
    
    const sx = CONFIG.STATION.x, sy = CONFIG.STATION.y;
    switch (this.priority) {
      case 'closest': cands.sort((a, b) => dist(a.x, a.y, sx, sy) - dist(b.x, b.y, sx, sy)); break;
      case 'fastest': cands.sort((a, b) => b.speed - a.speed); break;
      case 'strongest': cands.sort((a, b) => b.hp - a.hp); break;
      case 'highestThreat': cands.sort((a, b) => getThreat(b) - getThreat(a)); break;
      case 'weakest': cands.sort((a, b) => a.hp - b.hp); break;
      case 'longest': cands.sort((a, b) => b.timeIn - a.timeIn); break;
    }
    
    this.target = cands[0];
    if (this.kind === 'weapon') this.fire(state);
    else if (this.kind === 'utility') this.activate(state);
  }
  
  fire(state) {
    const t = this.target; let cd = this.cooldown;
    if (this.type === 'arc') cd *= state.perks.arcCooldown;
    this.cdT = cd; this.fireA = 300; this.fX = t.x; this.fY = t.y;
    
    if (this.type === 'pulse') {
      const maxT = this.maxT + (state.perks.pulseTargets || 0);
      const targets = state.enemies.filter(e => e.alive && dist(t.x, t.y, e.x, e.y) <= this.aoe).slice(0, maxT);
      targets.forEach(e => { if (e.takeDamage(this.damage)) this.onKill(e, state); });
      addEvent(state, `${this.name} поразил ${targets.length}`, 'success');
      state.effects.push({ type: 'pulse', x: t.x, y: t.y, radius: 0, color: this.color, time: 400 });
    } else {
      if (t.takeDamage(this.damage)) this.onKill(t, state);
      addEvent(state, `${this.name} поразил ${CONFIG.ENEMIES[t.type].name}`, 'success');
      state.effects.push({ type: 'beam', x: this.x, y: this.y, x1: this.x, y1: this.y, x2: t.x, y2: t.y, color: this.color, time: 200 });
    }
  }
  
  activate(state) {
    if (this.type === 'veil') {
      const slow = Math.min(0.9, this.slow + (state.perks.veilSlow || 0));
      const targets = state.enemies.filter(e => e.alive && dist(this.x, this.y, e.x, e.y) <= this.range);
      targets.forEach(e => { e.slowA = Math.max(e.slowA, slow); e.slowT = Math.max(e.slowT, this.slowDur); });
      this.cdT = this.cooldown; this.fireA = 500;
      addEvent(state, `${this.name} замедлил ${targets.length}`, 'info');
      state.effects.push({ type: 'veil', x: this.x, y: this.y, radius: this.range, color: this.color, time: 600 });
    }
  }
  
  onKill(e, state) {
    let r = e.reward;
    if (e.type === 'armored') r *= state.perks.armoredReward;
    r *= state.perks.creditBonus;
    state.credits += Math.round(r); state.score += e.score; state.killed++;
    addEvent(state, `Нейтрализован: +${Math.round(r)}¢`, 'success');
    
    if (e.type === 'armored') {
      for (let i = 0; i < 3; i++) {
        const a = (Math.PI * 2 * i) / 3;
        state.enemies.push(new Enemy('swarm', e.x + Math.cos(a) * 20, e.y + Math.sin(a) * 20));
      }
      addEvent(state, 'Carrier высвободил рои!', 'warning');
    }
    
    state.effects.push({ type: 'explosion', x: e.x, y: e.y, color: e.color, time: 500,
      particles: Array.from({ length: 12 }, () => ({ x: e.x, y: e.y, vx: (Math.random() - 0.5) * 4, vy: (Math.random() - 0.5) * 4, size: Math.random() * 3 + 1, life: 1, color: e.color })) });
  }
}

function upgCost(m) { if (m.level >= m.maxLevel) return null; return CONFIG.MODULES[m.type].upgrades[m.level - 1]?.cost ?? null; }
function sellVal(m) { return Math.floor(m.invested * 0.5); }

// ==================== GAME LOGIC ====================
function addEvent(state, text, type = 'info') {
  state.events.unshift({ text, type, time: Date.now() });
  if (state.events.length > 6) state.events.pop();
}

function startGame(state) {
  Object.assign(state, {
    phase: 'playing', credits: CONFIG.START.credits, energy: CONFIG.START.energy, maxEnergy: CONFIG.START.maxEnergy,
    integrity: CONFIG.STATION.maxIntegrity, maxIntegrity: CONFIG.STATION.maxIntegrity,
    score: 0, wave: 0, killed: 0, enemies: [], modules: [], effects: [], events: [],
    selModId: null, hiEnemyId: null, placeType: null, spawnQ: [], spawnT: 0, waveActive: false, endless: false,
    perks: { sensorRange: 1, arcCooldown: 1, veilSlow: 0, armoredReward: 1, guardianBurst: false, pulseTargets: 0, creditBonus: 1 },
    stress: CONFIG.START.stress, composure: CONFIG.START.composure, focus: CONFIG.START.focus, panic: 'calm',
    recovery: { mode: null, timer: 0, cooldowns: {} }, terrain: generateTerrain(state.terrainSeed)
  });
  addEvent(state, 'Игра начата!', 'info');
  startWave(state);
}

function startWave(state) {
  state.wave++; state.waveActive = true; state.spawnQ = []; state.spawnT = 0; state.phase = 'playing';
  if (state.wave <= CONFIG.WAVES.length) {
    const w = CONFIG.WAVES[state.wave - 1];
    w.enemies.forEach(g => { for (let i = 0; i < g.count; i++) state.spawnQ.push({ type: g.type, delay: w.delay * (state.spawnQ.length + 1), swarm: g.swarm }); });
  } else {
    state.endless = true;
    const wn = state.wave - CONFIG.WAVES.length, types = ['scout'];
    if (wn >= 2) types.push('swarm'); if (wn >= 3) types.push('decoy'); if (wn >= 4) types.push('armored'); if (wn >= 5) types.push('wisp');
    const cnt = 5 + Math.floor(wn * 1.5);
    for (let i = 0; i < cnt; i++) { const t = types[rndI(0, types.length - 1)]; state.spawnQ.push({ type: t, delay: Math.max(500, 2000 - wn * 50) * (i + 1), swarm: t === 'swarm' ? 3 + Math.floor(wn * 0.5) : undefined }); }
  }
  addEvent(state, `Волна ${state.wave} началась!`, 'warning');
}

function updateGame(state, dt) {
  if (state.phase !== 'playing') return;
  const adt = dt * state.speed;
  
  // Spawn
  state.spawnT += adt;
  state.spawnQ.filter(sp => sp.delay <= state.spawnT).forEach(sp => {
    const p = edgePos(); const hpS = state.endless ? 1 + (state.wave - CONFIG.WAVES.length) * 0.1 : 1;
    const spS = state.endless ? 1 + (state.wave - CONFIG.WAVES.length) * 0.03 : 1;
    if (sp.swarm && sp.type === 'swarm') { for (let i = 0; i < sp.swarm; i++) { const a = (Math.PI * 2 * i) / sp.swarm; state.enemies.push(new Enemy('swarm', p.x + Math.cos(a) * 20, p.y + Math.sin(a) * 20, hpS, spS)); } }
    else state.enemies.push(new Enemy(sp.type, p.x, p.y, hpS, spS));
  });
  state.spawnQ = state.spawnQ.filter(sp => sp.delay > state.spawnT);
  
  // Update enemies
  state.enemies.forEach(e => e.update(adt));
  state.enemies.filter(e => e.type === 'wisp' && e.disA).forEach(w => {
    state.modules.forEach(m => { if (dist(m.x, m.y, w.x, w.y) < 80) { m.disT = Math.max(m.disT, 100); m.disrupted = true; } });
  });
  
  // Update modules
  updateEnergy(state);
  state.modules.forEach(m => m.update(adt, state.enemies, state));
  
  // Process dead
  for (let i = state.enemies.length - 1; i >= 0; i--) {
    const e = state.enemies[i];
    if (!e.alive) {
      if (e.reached) {
        state.integrity -= e.dmg; state.stress = clamp(state.stress + 5, 0, 100); state.composure = clamp(state.composure - 3, 0, 100);
        addEvent(state, `Станция: -${e.dmg}`, 'danger');
        state.effects.push({ type: 'damageFlash', x: CONFIG.STATION.x, y: CONFIG.STATION.y, color: '#ff3355', time: 300 });
        audioMgr.hit();
        if (state.integrity <= 0) { state.integrity = 0; state.phase = 'gameover'; saveBest(state.score, state.wave); audioMgr.gameOver(); return; }
      }
      state.enemies.splice(i, 1);
    }
  }
  
  // Effects
  for (let i = state.effects.length - 1; i >= 0; i--) {
    const ef = state.effects[i]; ef.time -= adt;
    if (ef.type === 'pulse' && ef.radius !== undefined) ef.radius += 3 * adt * 0.1;
    if (ef.type === 'explosion' && ef.particles) ef.particles.forEach(p => { p.x += p.vx * adt * 0.05; p.y += p.vy * adt * 0.05; p.life -= adt * 0.003; });
    if (ef.time <= 0) state.effects.splice(i, 1);
  }
  
  // Module timers
  state.modules.forEach(m => { if (m.disT > 0) { m.disT -= adt; if (m.disT <= 0) m.disrupted = false; } if (m.fireA > 0) m.fireA -= adt; m.phase += adt * 0.003; });
  if (state.hiEnemyId && !state.enemies.find(e => e.id === state.hiEnemyId)) state.hiEnemyId = null;
  
  // Stress
  updateStress(state, adt);
  updateRecovery(state, adt);
  
  // Wave complete
  if (state.spawnQ.length === 0 && state.enemies.length === 0 && state.waveActive) {
    state.waveActive = false;
    const bonus = 50 + state.wave * 20;
    state.credits += bonus; state.focus = clamp(state.focus + 6, 0, 100);
    state.stress = clamp(state.stress - 10, 0, 100); state.composure = clamp(state.composure + 10, 0, 100);
    addEvent(state, `Волна ${state.wave} завершена! +${bonus}¢`, 'success');
    audioMgr.waveEnd();
    if (state.wave >= CONFIG.WAVES.length && !state.endless) { state.phase = 'victory'; saveBest(state.score, state.wave); }
    else state.phase = 'waveComplete';
  }
}

function updateStress(state, dt) {
  const close = state.enemies.filter(e => e.alive && dist(e.x, e.y, CONFIG.STATION.x, CONFIG.STATION.y) < CONFIG.RINGS[3].radius).length;
  const unknowns = state.enemies.filter(e => e.alive && e.type === 'decoy').length;
  let gain = (close * 0.3 + unknowns * 0.1 + (state.integrity < 50 ? 0.5 : 0) + (state.energy < 3 ? 0.3 : 0)) * (dt / 1000);
  if (state.recovery.mode === 'network-breath') gain *= 0.4;
  if (state.recovery.mode === 'channel-priority') gain = 0;
  gain *= 0.5;
  state.stress = clamp(state.stress + gain, 0, 100);
  if (state.enemies.length === 0 && !state.waveActive) state.stress = clamp(state.stress - dt * 0.005, 0, 100);
  else if (close === 0) state.stress = clamp(state.stress - dt * 0.001, 0, 100);
  if (state.stress > 70) state.composure = clamp(state.composure - dt * 0.002, 0, 100);
  else if (state.stress < 30) state.composure = clamp(state.composure + dt * 0.001, 0, 100);
  
  let focusRegen = 0;
  if (state.stress < 35) focusRegen = 0.7; else if (state.stress < 60) focusRegen = 0.35; else if (state.stress < 75) focusRegen = 0.1;
  state.focus = clamp(state.focus + focusRegen * (dt / 1000), 0, 100);
  
  const worst = Math.max(state.stress, 100 - state.composure);
  if (worst < 25) state.panic = 'calm'; else if (worst < 45) state.panic = 'alert'; else if (worst < 65) state.panic = 'tense'; else if (worst < 80) state.panic = 'critical'; else state.panic = 'overload';
  if (state.focus <= 20) state.focusVisual = 'low'; else if (state.focus >= 75) state.focusVisual = 'high'; else state.focusVisual = 'steady';
  if (state.recovery.mode === 'analysis-pause') state.focusVisual = 'analysis';
  if (state.recovery.mode === 'channel-priority') state.focusVisual = 'channel';
  if (state.recovery.mode === 'network-breath') state.focusVisual = 'breath';
  if (state.recovery.mode === 'clarity-protocol') state.focusVisual = 'clarity';
}

function updateRecovery(state, dt) {
  if (state.recovery.mode) { state.recovery.timer -= dt; if (state.recovery.timer <= 0) { state.recovery.mode = null; state.recovery.timer = 0; } }
  for (const k in state.recovery.cooldowns) if (state.recovery.cooldowns[k] > 0) state.recovery.cooldowns[k] -= dt;
}

function updateEnergy(state) {
  const total = state.modules.reduce((sum, m) => sum + (m.active ? m.energy : 0), 0);
  if (total > state.maxEnergy) {
    const sorted = [...state.modules].sort((a, b) => b.energy - a.energy);
    let used = 0;
    sorted.forEach(m => { if (used + m.energy <= state.maxEnergy) { m.active = true; m.lowPow = false; used += m.energy; } else { m.active = false; m.lowPow = true; } });
    state.energy = state.maxEnergy;
  } else { state.energy = state.maxEnergy; state.modules.forEach(m => { m.active = true; m.lowPow = false; }); }
}

function placeModule(state, type, x, y) {
  if (!validPlace(state, x, y)) return false;
  const d = CONFIG.MODULES[type];
  if (state.credits < d.cost || state.energy < d.energy) return false;
  state.credits -= d.cost; state.modules.push(new Module(type, x, y));
  state.selModId = state.modules[state.modules.length - 1].id; state.placeType = null;
  addEvent(state, `${d.name} размещён`, 'info');
  return true;
}

function validPlace(state, x, y) {
  const ds = dist(x, y, CONFIG.STATION.x, CONFIG.STATION.y);
  if (ds < CONFIG.STATION.radius + 30 || ds > CONFIG.RINGS[0].radius - 20) return false;
  for (const m of state.modules) if (dist(x, y, m.x, m.y) < 30) return false;
  return true;
}

function upgradeMod(state, id) {
  const m = state.modules.find(m => m.id === id); if (!m) return false;
  const c = upgCost(m); if (c === null || state.credits < c) return false;
  state.credits -= c; m.invested += c; m.level++;
  const u = CONFIG.MODULES[m.type].upgrades[m.level - 2];
  if (u.range) m.range = u.range; if (u.damage) m.damage = u.damage; if (u.cooldown) m.cooldown = u.cooldown;
  if (u.slow) m.slow = u.slow; if (u.aoe) m.aoe = u.aoe; if (u.maxT) m.maxT = u.maxT;
  addEvent(state, `${m.name} ур. ${m.level}`, 'info');
  return true;
}

function sellMod(state, id) {
  const m = state.modules.find(m => m.id === id); if (!m) return;
  state.credits += sellVal(m); state.energy = Math.min(state.maxEnergy, state.energy + m.energy);
  state.modules = state.modules.filter(x => x.id !== id);
  if (state.selModId === id) state.selModId = null;
  addEvent(state, `${m.name} продан`, 'info');
}

function applyPerk(state, id) {
  switch (id) {
    case 'sensor_range': state.perks.sensorRange *= 1.15; break;
    case 'arc_cooldown': state.perks.arcCooldown *= 0.88; break;
    case 'veil_slow': state.perks.veilSlow += 0.15; break;
    case 'max_energy': state.maxEnergy += 2; state.energy += 2; break;
    case 'armored_reward': state.perks.armoredReward *= 1.25; break;
    case 'pulse_targets': state.perks.pulseTargets += 2; break;
    case 'station_armor': state.maxIntegrity += 15; state.integrity = Math.min(state.integrity + 15, state.maxIntegrity); break;
    case 'credit_bonus': state.perks.creditBonus *= 1.1; break;
    case 'start_credits': state.credits += 100; break;
    case 'guardian_burst': state.perks.guardianBurst = true; break;
  }
  addEvent(state, `Улучшение: ${CONFIG.PERKS.find(p => p.id === id)?.name}`, 'info');
}

function randPerks(n = 3) { return shuffle(CONFIG.PERKS).slice(0, n); }

function canRecover(state, mode) {
  const cfg = CONFIG.RECOVERY[mode]; if (!cfg) return { ok: false, reason: '?' };
  if (state.recovery.mode) return { ok: false, reason: 'Активен' };
  if (state.focus < cfg.focus) return { ok: false, reason: `${cfg.focus} Focus` };
  const cd = state.recovery.cooldowns[mode] || 0;
  if (cd > 0) return { ok: false, reason: `КД ${Math.ceil(cd / 1000)}с` };
  return { ok: true, reason: '' };
}

function activateRecovery(state, mode) {
  const cfg = CONFIG.RECOVERY[mode];
  state.focus -= cfg.focus; state.recovery.mode = mode; state.recovery.timer = cfg.dur; state.recovery.cooldowns[mode] = cfg.cd;
  state.stress = clamp(state.stress + cfg.stress, 0, 100); state.composure = clamp(state.composure + cfg.composure, 0, 100);
}

// ==================== RENDERER ====================
function render(state) {
  const w = CONFIG.CANVAS_W, h = CONFIG.CANVAS_H;
  ctx.fillStyle = '#0a0e1a'; ctx.fillRect(0, 0, w, h);
  
  // Terrain
  state.terrain.regions.forEach(r => {
    const grad = ctx.createRadialGradient(r.x, r.y, 0, r.x, r.y, r.radius);
    grad.addColorStop(0, r.color); grad.addColorStop(1, 'rgba(0,0,0,0)');
    ctx.fillStyle = grad; ctx.beginPath(); ctx.arc(r.x, r.y, r.radius, 0, Math.PI * 2); ctx.fill();
  });
  
  // Grid
  ctx.strokeStyle = 'rgba(0,212,255,0.03)'; ctx.lineWidth = 1;
  for (let x = 0; x < w; x += 40) { ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, h); ctx.stroke(); }
  for (let y = 0; y < h; y += 40) { ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(w, y); ctx.stroke(); }
  
  // Rings
  const cx = CONFIG.STATION.x, cy = CONFIG.STATION.y;
  CONFIG.RINGS.forEach((r, i) => {
    ctx.beginPath(); ctx.arc(cx, cy, r.radius, 0, Math.PI * 2);
    ctx.strokeStyle = r.color; ctx.lineWidth = i === 3 ? 1.5 : 1;
    if (i === 0) ctx.setLineDash([5, 5]); ctx.stroke(); ctx.setLineDash([]);
  });
  
  // Enemies
  state.enemies.forEach(e => {
    if (!e.alive || (e.type === 'decoy' && !e.flickV)) return;
    if (e.trail.length > 1) { ctx.beginPath(); ctx.moveTo(e.trail[0].x, e.trail[0].y); for (let i = 1; i < e.trail.length; i++) ctx.lineTo(e.trail[i].x, e.trail[i].y); ctx.strokeStyle = e.color + '40'; ctx.lineWidth = 2; ctx.stroke(); }
    ctx.save(); ctx.translate(e.x, e.y); ctx.rotate(e.angle);
    ctx.fillStyle = e.color; ctx.strokeStyle = e.color; ctx.lineWidth = 1.5;
    switch (e.shape) {
      case 'triangle': ctx.beginPath(); ctx.moveTo(e.size, 0); ctx.lineTo(-e.size * 0.7, -e.size * 0.6); ctx.lineTo(-e.size * 0.7, e.size * 0.6); ctx.closePath(); ctx.fill(); break;
      case 'diamond': ctx.beginPath(); ctx.moveTo(e.size, 0); ctx.lineTo(0, -e.size * 0.6); ctx.lineTo(-e.size, 0); ctx.lineTo(0, e.size * 0.6); ctx.closePath(); ctx.fill(); break;
      case 'hexagon': ctx.beginPath(); for (let i = 0; i < 6; i++) { const a = (Math.PI * 2 * i) / 6; const px = Math.cos(a) * e.size; const py = Math.sin(a) * e.size; if (i === 0) ctx.moveTo(px, py); else ctx.lineTo(px, py); } ctx.closePath(); ctx.fill(); ctx.stroke(); break;
      case 'square': ctx.fillRect(-e.size * 0.7, -e.size * 0.7, e.size * 1.4, e.size * 1.4); break;
      case 'ring': ctx.beginPath(); ctx.arc(0, 0, e.size, 0, Math.PI * 2); ctx.lineWidth = 2; ctx.stroke(); break;
    }
    ctx.restore();
    if (e.hp < e.maxHp) { const bw = e.size * 2, bh = 3, bx = e.x - bw / 2, by = e.y - e.size - 8; ctx.fillStyle = 'rgba(0,0,0,0.5)'; ctx.fillRect(bx, by, bw, bh); const r = e.hp / e.maxHp; ctx.fillStyle = r > 0.5 ? '#00ff88' : r > 0.25 ? '#ffcc00' : '#ff3355'; ctx.fillRect(bx, by, bw * r, bh); }
    if (state.hiEnemyId === e.id) { ctx.strokeStyle = '#ffcc00'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(e.x, e.y, e.size + 6, 0, Math.PI * 2); ctx.stroke(); }
  });
  
  // Modules
  state.modules.forEach(m => {
    if (!m.active && !m.lowPow) return;
    if (state.selModId === m.id) {
      ctx.beginPath(); ctx.arc(m.x, m.y, m.range, 0, Math.PI * 2);
      ctx.strokeStyle = m.color + '30'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]); ctx.stroke(); ctx.setLineDash([]);
      if (m.target?.alive) { ctx.strokeStyle = m.color + '60'; ctx.lineWidth = 1; ctx.setLineDash([2, 4]); ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.target.x, m.target.y); ctx.stroke(); ctx.setLineDash([]); }
    }
    ctx.save(); ctx.translate(m.x, m.y);
    ctx.fillStyle = '#1a2a4a'; ctx.strokeStyle = m.color; ctx.lineWidth = 2;
    ctx.beginPath(); ctx.arc(0, 0, 12, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
    ctx.fillStyle = m.color; ctx.font = '8px monospace'; ctx.textAlign = 'center'; ctx.fillText(`L${m.level}`, 0, 3);
    if (m.lowPow) { ctx.fillStyle = '#ff3355'; ctx.fillText('!', 0, -18); }
    ctx.restore();
    if (m.fireA > 0) { const a = m.fireA / 300; ctx.strokeStyle = m.color + Math.floor(a * 255).toString(16).padStart(2, '0'); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(m.x, m.y); ctx.lineTo(m.fX, m.fY); ctx.stroke(); }
  });
  
  // Station
  const sg = ctx.createRadialGradient(cx, cy, CONFIG.STATION.radius * 0.5, cx, cy, CONFIG.STATION.radius * 2);
  sg.addColorStop(0, 'rgba(0,212,255,0.2)'); sg.addColorStop(1, 'rgba(0,212,255,0)');
  ctx.fillStyle = sg; ctx.beginPath(); ctx.arc(cx, cy, CONFIG.STATION.radius * 2, 0, Math.PI * 2); ctx.fill();
  ctx.fillStyle = '#1a2a4a'; ctx.strokeStyle = '#00d4ff'; ctx.lineWidth = 2;
  ctx.beginPath(); ctx.arc(cx, cy, CONFIG.STATION.radius, 0, Math.PI * 2); ctx.fill(); ctx.stroke();
  ctx.fillStyle = '#00d4ff'; ctx.beginPath(); ctx.arc(cx, cy, 4, 0, Math.PI * 2); ctx.fill();
  ctx.font = '10px monospace'; ctx.textAlign = 'center'; ctx.fillText('HELIOS', cx, cy + CONFIG.STATION.radius + 15);
  
  // Effects
  state.effects.forEach(ef => {
    if (ef.type === 'beam' && ef.x1 !== undefined) { const a = ef.time / 200; ctx.strokeStyle = ef.color + Math.floor(a * 255).toString(16).padStart(2, '0'); ctx.lineWidth = 3; ctx.beginPath(); ctx.moveTo(ef.x1, ef.y1); ctx.lineTo(ef.x2, ef.y2); ctx.stroke(); }
    if (ef.type === 'explosion' && ef.particles) ef.particles.forEach(p => { if (p.life > 0) { ctx.fillStyle = p.color + Math.floor(p.life * 255).toString(16).padStart(2, '0'); ctx.beginPath(); ctx.arc(p.x, p.y, p.size * p.life, 0, Math.PI * 2); ctx.fill(); } });
    if (ef.type === 'damageFlash') { ctx.fillStyle = `rgba(255,0,0,${ef.time / 600})`; ctx.fillRect(0, 0, w, h); }
  });
  
  // Placement preview
  if (state.placeType) { const d = CONFIG.MODULES[state.placeType]; const mx = state.mouseX, my = state.mouseY; ctx.beginPath(); ctx.arc(mx, my, d.range, 0, Math.PI * 2); ctx.strokeStyle = d.color + '40'; ctx.lineWidth = 1; ctx.setLineDash([4, 4]); ctx.stroke(); ctx.setLineDash([]); ctx.globalAlpha = 0.5; ctx.fillStyle = d.color; ctx.beginPath(); ctx.arc(mx, my, 12, 0, Math.PI * 2); ctx.fill(); ctx.globalAlpha = 1; const v = validPlace(state, mx, my); ctx.strokeStyle = v ? '#00ff88' : '#ff3355'; ctx.lineWidth = 2; ctx.beginPath(); ctx.arc(mx, my, 15, 0, Math.PI * 2); ctx.stroke(); }
}

// ==================== UI ====================
function updateUI(state) {
  // HUD
  document.getElementById('integrity-bar').style.width = `${(state.integrity / state.maxIntegrity) * 100}%`;
  document.getElementById('integrity-bar').style.background = state.integrity / state.maxIntegrity > 0.5 ? '#00ff88' : state.integrity / state.maxIntegrity > 0.25 ? '#ffcc00' : '#ff3355';
  document.getElementById('integrity-text').textContent = `${Math.round(state.integrity)}/${state.maxIntegrity}`;
  document.getElementById('credits-text').textContent = state.credits;
  document.getElementById('energy-bar').style.width = `${(state.energy / state.maxEnergy) * 100}%`;
  document.getElementById('energy-text').textContent = `${state.energy}/${state.maxEnergy}`;
  document.getElementById('focus-bar').style.width = `${state.focus}%`;
  document.getElementById('focus-text').textContent = Math.round(state.focus);
  document.getElementById('wave-text').textContent = `${state.wave}${state.endless ? '∞' : `/${CONFIG.WAVES.length}`}`;
  document.getElementById('score-text').textContent = state.score;
  document.getElementById('stress-text').textContent = Math.round(state.stress);
  document.getElementById('stress-text').style.color = state.panic === 'calm' ? '#00d4ff' : state.panic === 'alert' ? '#ffcc00' : state.panic === 'tense' ? '#ff8800' : '#ff3355';
  
  // Targets
  const targetList = document.getElementById('target-list');
  const sorted = [...state.enemies].filter(e => e.alive).sort((a, b) => getThreat(b) - getThreat(a)).slice(0, 8);
  document.getElementById('target-count').textContent = state.enemies.filter(e => e.alive).length;
  targetList.innerHTML = sorted.map(e => {
    const t = getThreat(e);
    return `<div class="target-item" data-id="${e.id}">
      <div class="target-icon" style="background: ${e.color}; clip-path: ${shapeClip(e.shape)}"></div>
      <span class="target-name">${CONFIG.ENEMIES[e.type].name}</span>
      <div class="target-threat">${[1,2,3,4,5].map(i => `<div class="threat-dot ${i <= t ? 'active' : ''}"></div>`).join('')}</div>
      <span class="target-hp">${Math.round(e.hp)}</span>
    </div>`;
  }).join('');
  
  targetList.querySelectorAll('.target-item').forEach(item => {
    item.onclick = () => { state.hiEnemyId = item.dataset.id; };
  });
  
  // Selected module
  const selMod = state.modules.find(m => m.id === state.selModId);
  const selDiv = document.getElementById('selected-module');
  if (selMod) {
    const uc = upgCost(selMod);
    selDiv.innerHTML = `
      <div class="module-info-row"><span class="module-info-label">Модуль</span><span class="module-info-value" style="color: ${selMod.color}">${selMod.name}</span></div>
      <div class="module-info-row"><span class="module-info-label">Уровень</span><span class="module-info-value">${selMod.level}/${selMod.maxLevel}</span></div>
      <div class="module-info-row"><span class="module-info-label">Дальность</span><span class="module-info-value">${Math.round(selMod.range)}</span></div>
      ${selMod.damage > 0 ? `<div class="module-info-row"><span class="module-info-label">Урон</span><span class="module-info-value">${selMod.damage}</span></div>` : ''}
      <div class="module-info-row"><span class="module-info-label">Статус</span><span class="module-info-value" style="color: ${selMod.disrupted ? '#ff3355' : selMod.lowPow ? '#ffcc00' : '#00ff88'}">${selMod.disrupted ? 'Помехи' : selMod.lowPow ? 'Мало EN' : 'Активен'}</span></div>
      ${selMod.kind === 'weapon' ? `<select id="mod-priority" style="width: 100%; margin-top: 6px; padding: 3px; background: #0a0e1a; border: 1px solid #2a3a5c; border-radius: 3px; color: #e0e8f0; font-size: 10px;">
        ${CONFIG.PRIORITIES.map(p => `<option value="${p.id}" ${selMod.priority === p.id ? 'selected' : ''}>${p.name}</option>`).join('')}
      </select>` : ''}
      <div class="module-actions">
        ${uc !== null ? `<button class="btn-upgrade" id="btn-upgrade" ${state.credits < uc ? 'disabled' : ''}>⬆ ${uc}¢</button>` : ''}
        <button class="btn-sell" id="btn-sell">💰 ${sellVal(selMod)}¢</button>
      </div>
    `;
    
    const prioritySelect = document.getElementById('mod-priority');
    if (prioritySelect) prioritySelect.onchange = (e) => { selMod.priority = e.target.value; };
    
    const upgradeBtn = document.getElementById('btn-upgrade');
    if (upgradeBtn) upgradeBtn.onclick = () => { if (upgradeMod(state, selMod.id)) { audioMgr.upgrade(); updateUI(state); } };
    
    const sellBtn = document.getElementById('btn-sell');
    if (sellBtn) sellBtn.onclick = () => { sellMod(state, selMod.id); audioMgr.click(); updateUI(state); };
  } else {
    selDiv.innerHTML = '<p class="empty-text">Выберите модуль</p>';
  }
  
  // Panic
  const panicText = document.getElementById('panic-text');
  panicText.textContent = state.panic === 'calm' ? 'Спокойно' : state.panic === 'alert' ? 'Внимание' : state.panic === 'tense' ? 'Напряжение' : state.panic === 'critical' ? 'Критическое' : 'Перегрузка';
  panicText.style.color = state.panic === 'calm' ? '#00d4ff' : state.panic === 'alert' ? '#ffcc00' : state.panic === 'tense' ? '#ff8800' : '#ff3355';
  
  // Events
  const logDiv = document.getElementById('event-log');
  logDiv.innerHTML = state.events.map(ev => `<div class="event-item ${ev.type}">${ev.text}</div>`).join('');
}

function shapeClip(shape) {
  switch (shape) {
    case 'triangle': return 'polygon(50% 0%, 100% 100%, 0% 100%)';
    case 'diamond': return 'polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%)';
    case 'hexagon': return 'polygon(25% 0%, 75% 0%, 100% 50%, 75% 100%, 25% 100%, 0% 50%)';
    case 'square': return 'polygon(0% 0%, 100% 0%, 100% 100%, 0% 100%)';
    case 'ring': return 'circle(50%)';
    default: return 'circle(50%)';
  }
}

function buildModuleList(state) {
  const list = document.getElementById('module-list');
  list.innerHTML = Object.entries(CONFIG.MODULES).map(([key, data]) => `
    <div class="module-card ${state.credits < data.cost ? 'disabled' : ''}" data-type="${key}">
      <div class="module-card-header">
        <span class="module-card-name" style="color: ${data.color}">${data.name}</span>
        <span class="module-card-cost">${data.cost}¢</span>
      </div>
      <div class="module-card-desc">${data.desc}</div>
    </div>
  `).join('');
  
  list.querySelectorAll('.module-card:not(.disabled)').forEach(card => {
    card.onclick = () => { state.placeType = card.dataset.type; audioMgr.click(); };
  });
}

function buildRecoveryList(state) {
  const list = document.getElementById('recovery-list');
  const hotkeys = { 'analysis-pause': 'Q', 'channel-priority': 'W', 'network-breath': 'E', 'clarity-protocol': 'R' };
  list.innerHTML = Object.entries(CONFIG.RECOVERY).map(([key, cfg]) => {
    const check = canRecover(state, key);
    const cd = state.recovery.cooldowns[key] || 0;
    const active = state.recovery.mode === key;
    return `<button class="recovery-btn" data-mode="${key}" ${!check.ok ? 'disabled' : ''}>
      <div style="font-weight: 600">${cfg.name} [${hotkeys[key]}]</div>
      <div style="font-size: 8px; color: #8899aa">${active ? `${Math.ceil(state.recovery.timer / 1000)}с` : cd > 0 ? `КД ${Math.ceil(cd / 1000)}с` : check.reason || '✓'}</div>
    </button>`;
  }).join('');
  
  list.querySelectorAll('.recovery-btn:not(:disabled)').forEach(btn => {
    btn.onclick = () => { activateRecovery(state, btn.dataset.mode); audioMgr.recovery(); updateUI(state); };
  });
}

// ==================== MODALS ====================
function showModal(id) { document.getElementById(id).classList.remove('hidden'); }
function hideModal(id) { document.getElementById(id).classList.add('hidden'); }
function hideAllModals() { document.querySelectorAll('.modal').forEach(m => m.classList.add('hidden')); }

function showWaveEnd(state) {
  const perks = randPerks(3);
  document.getElementById('wave-summary').textContent = `Кредиты: ${state.credits}`;
  document.getElementById('perk-selection').innerHTML = perks.map(p => `
    <div class="perk-option" data-id="${p.id}">
      <div class="perk-name">${p.name}</div>
      <div class="perk-desc">${p.desc}</div>
    </div>
  `).join('');
  
  document.querySelectorAll('.perk-option').forEach(opt => {
    opt.onclick = () => { applyPerk(state, opt.dataset.id); hideModal('modal-wave-end'); startWave(state); audioMgr.waveStart(); };
  });
  
  showModal('modal-wave-end');
}

// ==================== GAME LOOP ====================
function gameLoop(time) {
  const dt = Math.min(time - lastTime, 50);
  lastTime = time;
  
  if (gameState.phase === 'playing') updateGame(gameState, dt);
  
  render(gameState);
  updateUI(gameState);
  buildModuleList(gameState);
  buildRecoveryList(gameState);
  
  // Show modals
  if (gameState.phase === 'waveComplete' && !document.getElementById('modal-wave-end').classList.contains('hidden') === false) showWaveEnd(gameState);
  if (gameState.phase === 'gameover') {
    document.getElementById('game-over-stats').innerHTML = `<p>Очки: <strong style="color: #00ff88">${gameState.score}</strong></p><p>Волна: <strong>${gameState.wave}</strong></p><p>Рекорд: <strong style="color: #ffcc00">${gameState.bestScore}</strong></p>`;
    showModal('modal-game-over');
  }
  if (gameState.phase === 'victory') {
    document.getElementById('victory-stats').innerHTML = `<p>Очки: <strong style="color: #00ff88">${gameState.score}</strong></p>`;
    showModal('modal-victory');
  }
  
  animId = requestAnimationFrame(gameLoop);
}

// ==================== INIT ====================
function init() {
  canvas = document.getElementById('gameCanvas');
  ctx = canvas.getContext('2d');
  audioMgr = new AudioMgr();
  gameState = initState();
  
  // Canvas events
  canvas.addEventListener('mousemove', (e) => {
    const rect = canvas.getBoundingClientRect();
    gameState.mouseX = (e.clientX - rect.left) * (canvas.width / rect.width);
    gameState.mouseY = (e.clientY - rect.top) * (canvas.height / rect.height);
  });
  
  canvas.addEventListener('click', (e) => {
    if (gameState.phase !== 'playing') return;
    const rect = canvas.getBoundingClientRect();
    const x = (e.clientX - rect.left) * (canvas.width / rect.width);
    const y = (e.clientY - rect.top) * (canvas.height / rect.height);
    
    if (gameState.placeType) {
      if (placeModule(gameState, gameState.placeType, x, y)) audioMgr.place();
      return;
    }
    
    let cm = null;
    for (const m of gameState.modules) if (Math.hypot(x - m.x, y - m.y) < 20) { cm = m; break; }
    if (cm) { gameState.selModId = cm.id; gameState.hiEnemyId = null; return; }
    
    let ce = null;
    for (const e of gameState.enemies) if (e.alive && Math.hypot(x - e.x, y - e.y) < e.size + 5) { ce = e; break; }
    if (ce) { gameState.hiEnemyId = ce.id; gameState.selModId = null; return; }
    
    gameState.selModId = null; gameState.hiEnemyId = null;
  });
  
  canvas.addEventListener('contextmenu', (e) => { e.preventDefault(); gameState.placeType = null; });
  
  // Keyboard
  document.addEventListener('keydown', (e) => {
    if (e.ctrlKey && e.shiftKey && e.key === 'P') { e.preventDefault(); gameState.adminOpen = !gameState.adminOpen; document.getElementById('admin-panel').classList.toggle('hidden'); return; }
    if (e.code === 'Space') { e.preventDefault(); if (gameState.phase === 'playing') { gameState.phase = 'paused'; showModal('modal-pause'); } else if (gameState.phase === 'paused') { gameState.phase = 'playing'; hideModal('modal-pause'); audioMgr.unlock(); } }
    if (e.key === '1') gameState.speed = 1;
    if (e.key === '2') gameState.speed = 2;
    if (e.key === 'Escape') { if (gameState.adminOpen) { gameState.adminOpen = false; document.getElementById('admin-panel').classList.add('hidden'); } else gameState.placeType = null; }
    if (e.key === 'q') { const c = canRecover(gameState, 'analysis-pause'); if (c.ok) { activateRecovery(gameState, 'analysis-pause'); audioMgr.recovery(); } }
    if (e.key === 'w' && !e.ctrlKey) { const c = canRecover(gameState, 'channel-priority'); if (c.ok) { activateRecovery(gameState, 'channel-priority'); audioMgr.recovery(); } }
    if (e.key === 'e') { const c = canRecover(gameState, 'network-breath'); if (c.ok) { activateRecovery(gameState, 'network-breath'); audioMgr.recovery(); } }
  });
  
  // Buttons
  document.getElementById('btn-start').onclick = () => { audioMgr.init(); audioMgr.unlock(); hideModal('modal-start'); startGame(gameState); };
  document.getElementById('btn-resume').onclick = () => { gameState.phase = 'playing'; hideModal('modal-pause'); };
  document.getElementById('btn-pause').onclick = () => { if (gameState.phase === 'playing') { gameState.phase = 'paused'; showModal('modal-pause'); } else if (gameState.phase === 'paused') { gameState.phase = 'playing'; hideModal('modal-pause'); } };
  document.getElementById('btn-speed').onclick = () => { gameState.speed = gameState.speed === 1 ? 2 : 1; document.getElementById('btn-speed').textContent = `×${gameState.speed}`; };
  document.getElementById('btn-restart').onclick = () => { gameState = initState(); hideAllModals(); showModal('modal-start'); };
  document.getElementById('btn-retry').onclick = () => { gameState = initState(); hideAllModals(); startGame(gameState); };
  document.getElementById('btn-endless').onclick = () => { hideModal('modal-victory'); startWave(gameState); };
  document.getElementById('btn-restart-victory').onclick = () => { gameState = initState(); hideAllModals(); showModal('modal-start'); };
  document.getElementById('btn-next-wave').onclick = () => { hideModal('modal-wave-end'); startWave(gameState); audioMgr.waveStart(); };
  document.getElementById('btn-admin').onclick = () => { gameState.adminOpen = !gameState.adminOpen; document.getElementById('admin-panel').classList.toggle('hidden'); };
  document.getElementById('btn-close-admin').onclick = () => { gameState.adminOpen = false; document.getElementById('admin-panel').classList.add('hidden'); };
  
  // Admin tabs
  document.querySelectorAll('.admin-tab').forEach(tab => {
    tab.onclick = () => {
      document.querySelectorAll('.admin-tab').forEach(t => t.classList.remove('active'));
      document.querySelectorAll('.admin-tab-content').forEach(c => c.classList.remove('active'));
      tab.classList.add('active');
      document.getElementById(`tab-${tab.dataset.tab}`).classList.add('active');
    };
  });
  
  // Admin settings
  document.getElementById('admin-sound').onchange = (e) => { gameState.soundOn = e.target.checked; audioMgr.setMuted(!gameState.soundOn); saveSettings({ sound: gameState.soundOn }); };
  document.getElementById('admin-music-vol').oninput = (e) => { gameState.musicVolume = parseFloat(e.target.value); audioMgr.setMusicVol(gameState.musicVolume); };
  document.getElementById('admin-contrast').onchange = (e) => { gameState.highContrast = e.target.checked; document.body.classList.toggle('high-contrast', gameState.highContrast); saveSettings({ highContrast: gameState.highContrast }); };
  document.getElementById('admin-motion').onchange = (e) => { gameState.reduceMotion = e.target.checked; saveSettings({ reduceMotion: gameState.reduceMotion }); };
  document.getElementById('admin-visual').onchange = (e) => { gameState.reduceVisual = e.target.checked; saveSettings({ reduceVisual: gameState.reduceVisual }); };
  document.getElementById('admin-large-text').onchange = (e) => { gameState.largeText = e.target.checked; document.body.classList.toggle('large-text', gameState.largeText); saveSettings({ largeText: gameState.largeText }); };
  document.getElementById('btn-regen-terrain').onclick = () => { gameState.terrainSeed = Math.floor(Math.random() * 10000); gameState.terrain = generateTerrain(gameState.terrainSeed); document.getElementById('terrain-seed').textContent = gameState.terrainSeed; saveSettings({ terrainSeed: gameState.terrainSeed }); };
  document.getElementById('btn-clear-data').onclick = () => { if (confirm('Очистить все данные?')) { clearSave(); gameState = initState(); hideAllModals(); showModal('modal-start'); } };
  
  // Music
  document.getElementById('admin-music-file').onchange = (e) => {
    const files = Array.from(e.target.files);
    files.forEach(f => {
      const url = URL.createObjectURL(f);
      gameState.musicFiles.push({ name: f.name, url });
    });
    if (gameState.musicFiles.length > 0) {
      audioMgr.loadMusic(gameState.musicFiles[0].url);
      document.getElementById('music-player').classList.remove('hidden');
      document.getElementById('music-current').textContent = gameState.musicFiles[0].name;
    }
  };
  document.getElementById('btn-music-play').onclick = () => { if (gameState.musicPlaying) { audioMgr.pauseMusic(); gameState.musicPlaying = false; document.getElementById('btn-music-play').textContent = '▶'; } else { audioMgr.playMusic(); gameState.musicPlaying = true; document.getElementById('btn-music-play').textContent = '⏸'; } };
  document.getElementById('btn-music-stop').onclick = () => { audioMgr.stopMusic(); gameState.musicPlaying = false; document.getElementById('btn-music-play').textContent = '▶'; };
  
  // Start game loop
  lastTime = performance.now();
  animId = requestAnimationFrame(gameLoop);
}

// Start
window.addEventListener('DOMContentLoaded', init);
